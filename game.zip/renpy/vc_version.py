branch = u'fix'
nightly = False
official = True
version = u'7.8.4.24120703'
version_name = u'Straight on Till Morning'
